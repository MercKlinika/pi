1. Place lcdSongInfo.py in /home/pi/Adafruit-Raspberry-Pi-Python-Code/Adafruit_CharLCDPlate
2. Place start_lcdSongInfo.sh in /etc/init.d
3. Make sure both scripts are executabls (chmod 755 script).
4. Run "sudo update-rc.d start_lcdSongInfo.sh defaults" to add to startup (init) files.
5. reboot